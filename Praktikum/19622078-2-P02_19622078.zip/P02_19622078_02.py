# NIM/Nama : 19622078 / Raden Francisco Trianto Bratadiningrat
# Tanggal : 12 Oktober 2022
# Deskripsi : Menghitung permen maksimal yang bisa didapat dari permen yang dibeli dan ditukar bungkusnya

# KAMUS :
#   n, k, total, jumlah : int

# ALGORITMA

# meminta input data, n sebagai permen awal, k sebagi jumlah bungkus yang ditukar untuk bonus 1 permen
n = int(input("Masukkan banyak permen yang dibeli di awal: "))
k = int(input("Masukkan bilangan K: ")) 
while k<=1:
    # jika k = 1 maka maksimum permen adalah tak hingga
    print("K tidak boleh <= 1")
    k = int(input("Masukkan bilangan K: ")) 
# inisialisasi total permen yang didapat dan jumlah bungkus saat ini
total,jumlah = n, n
# selama jumlah bungkus bisa ditukar maka loop berjalan, jika sudah tidak bisa maka berhenti
while jumlah >= k:
    #total permen ditambah dengan bonus tukar bungkus dengan permen, yaitu sisa bagi jumlah bungkus oleh K
    total = total + (jumlah//k)
    #jumlah dikurang dengan bungkus yang ditukar dan ditambah bonusnya
    jumlah = jumlah - ((jumlah//k)*k) + (jumlah//k)
# output total permen yang bisa didapat
print(f"Jumlah maksimal permen yang didapat Tuan Riz adalah {total} permen.")