# NIM/Nama : 19622078 / Raden Francisco Trianto Bratadiningrat
# Tanggal : 12 Oktober 2022
# Deskripsi : Mengelompokan nomor kamar dengan kelompok makannya yang didapat dari hasil penjumlahan digit hingga tersisa 1 digit

# KAMUS :
#   n, bilskrg, jumlah_digit: int
#   digit : string

# ALGORITMA

# meminta input nomor kamar sebagai n
n = int(input("Masukkan nomor kamar: "))
# inisialisasi bilangan sekarang sebagai bilangan saat ini yang berubah dengan pengulanan 
bilskrg = n
print(n,end="")
# pengulangan selama jumlah digit lebih besar dari 1 digit
while len(str(bilskrg)) > 1:
    # inisialisasi jumlah digit karena diperlukan untuk menghitung jumlah digit dari bilangan sekarang
    jumlah_digit = 0
    # pengulangan untuk setiap digit dalam bilskrg yang akan ditambahkan ke dalam jumlah_digit
    for digit in str(bilskrg):
        jumlah_digit = jumlah_digit + int(digit)
    # mengganti bilangan sekarang (bilangan lama untuk pengulangan saat ini) menjadi hasil penjumlahan digit dari bilangan sekarang yang sebelumnya
    bilskrg = jumlah_digit
    print(f" -> {bilskrg}",end="")
# output bilangan sekarang yang terdiri dari 1 digit saja yang menjadi nomor kelompok ruangan
print(f"\nKamar {n} akan termasuk ke dalam ruang makan {bilskrg}.")