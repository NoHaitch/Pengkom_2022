# NIM/Nama : 19622078 / Raden Francisco Trianto Bratadiningrat
# Tanggal : 12 Oktober 2022
# Deskripsi : Permainan suit Jepang Tuan Leo dan Tuan Riz, gunting - kertas - batu, poin paling tinggi menang, jika menang poin+1, jika seri keduanya poin+1 

# KAMUS :
#   n, poinLeo, poinRiz : int
#   gerakLeo, gerakRiz : string

# ALGORITMA

# masukan jumlah ronde sebagai n
n = int(input("Masukkan jumlah ronde permainan: "))
# inisialisasi poin milik Tuan Leo dan Tuan Riz
poinLeo, poinRiz = 0,0
# looping ronde dari 1 hingga n
for ronde in range(1,n+1):
    # meminta gerakan masing-masing
    gerakLeo = input(f"Masukkan gerakan Tuan Leo ke-{ronde}: ")
    gerakRiz = input(f"Masukkan gerakan Tuan Riz ke-{ronde}: ")
    #percabangan, di mana yang menang poin+1, jika seri keduanya poin+1
    #siklus G --> K --> B --> G 
    # menang jika dengan arah dalam siklus searah, kalah jika dengan arah dalam siklus berlawanan
    if(gerakLeo == "G"):
        if(gerakRiz == "G"):
            poinLeo = poinLeo + 1
            poinRiz = poinRiz + 1
        elif(gerakRiz == "K"):
            poinLeo = poinLeo + 1
        elif(gerakRiz == "B"): 
            poinRiz = poinRiz + 1
    elif(gerakLeo == "K"):
        if(gerakRiz == "G"):
            poinRiz = poinRiz + 1
        elif(gerakRiz == "K"):
            poinLeo = poinLeo + 1
            poinRiz = poinRiz + 1
        elif(gerakRiz == "B"): 
            poinLeo = poinLeo + 1
    elif(gerakLeo == "B"):
        if(gerakRiz == "G"):
            poinLeo = poinLeo + 1
        elif(gerakRiz == "K"):
            poinRiz = poinRiz + 1
        elif(gerakRiz == "B"):
            poinRiz = poinRiz + 1
            poinLeo = poinLeo + 1
# jika poin Tuan Riz lebih besar dari Tuan Leo
if(poinRiz > poinLeo):
    print("Pemenangnya adalah Tuan Riz.")
# jika seri
elif(poinRiz == poinLeo):
    print("Permainan berakhir seri.")
else: # jika poin Tuan Riz lebih kecil dari Tuan Leo
    print("Pemenangnya adalah Tuan Leo.")