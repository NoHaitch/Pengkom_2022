# NIM/Nama : 19622078 / Raden Francisco Trianto Bratadiningrat
# Tanggal : 28 September 2022
# Deskripsi : aplikasi jam dengan format 24 jam dengan jam, menit detik serta 3 mode
"""
Kamus :
    jam, menit, detik, perubahan : int
    mode : string
Asumsi :
    input integer pasti bilangan bulat
    input mode pasti diantara "J", "M", dan "D"
"""
print("Keadaaan Awal: ")
jam = int(input("Jam : "))
menit = int(input("Menit : "))
detik = int(input("Detik : "))
mode = input("Mode : ")
perubahan = int(input("Nilai perubahan : "))

if(mode == "J"):
    jam += perubahan
elif(mode == "M"):
    menit += perubahan
else: # mode == "D"
    detik += perubahan

# kasus jika bukan 0<jam<=23
if(jam >= 24):
    jam -= (jam//24)*24
elif(jam < 0):
    jam += (((jam*-1) // 24)+1)*24

# kasus jika bukan 0<menit<=60
if(menit >= 60):
    menit -= (menit//60)*60
elif(menit < 0):
    menit += (((menit*-1) // 60)+1)*60
    
# kasus jika bukan 0<detik<=60
if(detik >= 60):
    detik -= (detik//60)*60
elif(detik < 0):
    detik += (((detik*-1) // 60)+1)*60

print(f"Waktu Sekarang adalah: {jam:02d}:{menit:02d}:{detik:02d}")
