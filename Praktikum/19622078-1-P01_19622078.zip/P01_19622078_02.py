# NIM/Nama : 19622078 / Raden Francisco Trianto Bratadiningrat
# Tanggal : 28 September 2022
# Deskripsi : teka teki aritmetika dari 4 bilangan bulat, 
#           Cek 3 bilangan awal aritmetika bukan,
#           jika iya:
#               jika bilangan terkahir adalah suku dari 4 bilangan sebelumnya: 
#                   jika iya: Suku berapakah bilangan terkahir
#           jika tidak: tidak dicari suku terakhir
# syarat: barisan aritmetika memiliki selisih yang sama pada setiap suku

"""
KAMUS:
    n1,n2,n3,n4 : int
    interval : int
Asumsi :
    input integer bilangan bulat positif
"""
n1 = int(input("Masukan bilangan pertama : "))
n2 = int(input("Masukan bilangan kedua : "))
n3 = int(input("Masukan bilangan ketiga : "))

#cek jika barisan aritmetika
if((n2-n1)==(n3-n2)):
    interval = n2-n1
    #karena barisan aritmetika maka minta bilangan keempat
    n4 = int(input("Masukan bilangan keempat : "))
    if((n4-n1) % interval == 0):
        print(f"Bilangan {n4} merupakan suku ke-{((n4-n1)//interval)+1} dari barisan aritmetika")
    else:
        print(f"bilangan {n4} bukan merupakan suku dari barisan aritmetika")
else:
    print("Bukan merupakan barisan aritmetika")