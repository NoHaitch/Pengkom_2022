# NIM/Nama : 19622078 / Raden Francisco Trianto Bratadiningrat
# Tanggal : 28 September 2022
# Deskripsi : Menyimpan 3 kotak dengan berat masing-masing ke dalam jumlah karung dengan batas berat
"""
Kamus :
    a, b, c, K, total : int
Asumsi :
    input integer pasti bilangan bulat positif (x > 0)
"""

a = int(input("Berat kotak A: "))
b = int(input("Berat kotak B: "))
c = int(input("Berat kotak C: "))
K = int(input("Kapasitas karung: "))
total = 0
# jika salah satu lebih besar dari kapasitas karung
if(a > K or b > K or c > K):
    print("Tuan Kil tidak dapat menyimpan seluruh kotak")
else:
    # Cek jika ketiga barang bisa dimasukan dalam satu karung
    if(a+b+c <= K):
        total = 1
    # karena tidak bisa maka cek apakah ada dua kotak yg bisa dimasukan satu karung
    elif(a+b<=K or a+c<=K or b+c<=K):
        total = 2   
    else: # karena tidak bisa semua, maka satu kotak dimasukan dalam satu karung masing-masing
        total = 3   
    print(f"Tuan Kil memerlukan {total} karung")
