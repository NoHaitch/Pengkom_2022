# NIM/Nama : 19622078 / Raden Francisco Trianto Bratadiningrat
# Tanggal : 26 Oktober 2022
# Deskripsi : Dari kumpulan angak tidak terurut, tentukan banyak grup angak terurut yang dapat dibentuk dari array tersebut

# KAMUS :
#   n, i, x, y, grup, isudah, tempisudah : int
#   data, sudah : array int

# ALGORITMA

# meminta input
n = int(input("Masukkan banyak data: "))
# inisialisasi data
data = [0 for _ in range(n)]
for i in range(n):
    data[i] = int(input(f"Masukkan data ke-{i+1}: "))
# inisialisasi sudah untuk diisi elemen yang sudah dipakai dengan indeks saat ini sebagai isudah
sudah = [0 for _ in range(n)] 
isudah = 0   
grup = 0
for x in range(n):
    # jika elemen belum digunakan
    if(not (data[x] in sudah)):
        sudah[isudah] = data[x]
        isudah = isudah + 1
        tempisudah = 0
        # pengulangan hingga tidak ada lagi nilai yang berada dalam satu grup
        while tempisudah <= isudah:
            for y in range(n):
                if((not (data[y] in sudah)) and tempisudah != y):
                    if(data[y] == sudah[tempisudah]+1 or data[y] == sudah[tempisudah]-1):
                        sudah[isudah] = data[y]
                        isudah = isudah + 1
                        tempisudah = 0
            tempisudah = tempisudah + 1   
        grup =  grup + 1   
print(f"Banyak grup angka terturut adalah {grup}.")             
        
   