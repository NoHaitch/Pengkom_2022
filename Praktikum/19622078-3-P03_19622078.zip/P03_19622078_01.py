# NIM/Nama : 19622078 / Raden Francisco Trianto Bratadiningrat
# Tanggal : 26 Oktober 2022
# Deskripsi : Mencari letak nilai x(dicari) ke-N(ndicari) pada sebuah array

# KAMUS :
#   n, i, dicari, ndicari, indeks, nskrg: int
#   data : array int

# ALGORITMA

# meminta jumlah data
n = int(input("Masukkan nilai banyak data: "))
# inisialisasi data
data = [0 for _ in range(n)]
# meminta semua isi array data
for i in range(n):
    data[i] = int(input(f"Masukkan data ke-{i+1}: "))
# meminta nilai yang dicari dan penemuan tujuan
dicari = int(input("Masukkan nilai yang dicari: "))
ndicari = int(input("Masukkan nilai N: "))
# jika N > total data maka tidak mungkin ditemukan
while ndicari > n:
    print("nilai N tidak mungkin melebihi jumlah data")
    ndicari = int(input("Masukkan nilai N: "))
# menghitung penemuan nilai yang dicari sebagai nskrg
nskrg = 0
# inisialisasi indeks dengan nilai -1 untuk menjaga agar pengubahan nilai indeks hanya terjadi sekali
indeks = -1
# pengulangan semua data dan i sebagai indeks
for i in range(n):
    # jika indeks yang dicari sudah ditemukan maka isi loop tidak perlu dilanjutkan
    if(indeks != -1):
        continue
    # jika nilai data[i] sama dengan yang dicari maka penemuan(nskrg) ditambah 1
    if(data[i] == dicari):
        nskrg = nskrg + 1
    # jika penemuan sekarang sudah sama dengan penemuan tujuan maka indeks sudah ditemukan
    if(nskrg == ndicari):
        indeks = i 
# jika nilai indeks tidak berubah dan tetap -1 maka nilai tidak ditemukan
if(indeks == -1):
    print("Nilai {dicari} tidak ditemukan.")
else:
    # output jika ditemukan
    print(f"Nilai {dicari} ke-{ndicari} berada pada indeks {indeks}.")