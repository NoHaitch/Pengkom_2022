# NIM/Nama : 19622078 / Raden Francisco Trianto Bratadiningrat
# Tanggal : 26 Oktober 2022
# Deskripsi : Mencari banyak kemunculan kodon dalam rantai DNA

# KAMUS :
#   n, i, j muncul, count : int
#   rantai, kodon : string

# ALGORITMA

# Meminta input 
n = int(input("Masukkan panjang rantai: "))
rantai = input("Masukkan rantai DNA: ")
# jika panjang tidak sama maka masuk pengulangan
while len(rantai) != n:
    print("pastikan panjang rantai sama")
    rantai = input("Masukkan rantai DNA: ")
kodon = input("Masukkan kodon yang dicari: ")
# inisialisai jumlah kemunculan sebagai muncul
muncul = 0
# pengulangan semua elemen rantai dengan string indexing (menganggap string sebagai array yang terbuat dari karakter)
for i in range(n):
    # jika huruf pada rantai sama dengan huruf pertama kodon 
    if(rantai[i] == kodon[0]):
        # inisialisasi count untuk mengecek apakah semua huruf Kodon sama dengan di rantai
        count = 0
        for j in range(len(kodon)):
            # jika index tidak melebihi maksimum index rantai
            if(i+j <= len(rantai)-1):
                if(rantai[i+j] == kodon[j]):
                    # huruf sama sehingga count ditambah 1
                    count = count + 1
        # jika count sama dengan panjang kodon maka benar terjadi kemunculan kodon mulai dari index i
        if(count == len(kodon)):
            muncul = muncul + 1
# jika muncul maka bernilai lebih besar dari 1 
if(muncul != 0):
    print(f"Kodon {kodon} muncul sebanyak {muncul} kali.")
else: # muncul = 0, berarti tidak ada kemunculan kodon
    print(f"Kodon {kodon} tidak muncul pada rantai DNA.")